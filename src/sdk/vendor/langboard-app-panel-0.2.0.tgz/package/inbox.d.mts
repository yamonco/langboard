import type { PanelSession, JsonValue } from './index.mjs';
export interface SignalRow {provider:string; resource_name?:string; external_id?:string; commit_sha?:string; event_type?:string; outcome?:string|null; conflict?:boolean; [key:string]:JsonValue|undefined;}
export interface InboxState {items:SignalRow[];nextCursor:string|null;busy:boolean;error:string;}
export function filterSignals(items:SignalRow[],provider:string,query?:string,outcome?:string):SignalRow[];
export function createSignalInbox(session:Pick<PanelSession,'signal'|'request'>,provider:string,changed:(state:InboxState)=>void):{load(more?:boolean):Promise<void>};
