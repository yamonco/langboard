"""Inspect authority and persist request acceptance; neither starts execution."""

from typing import Literal, NotRequired, TypedDict, cast
from .resources import _uid
from .rest import ApiTransport


class ExecutionAuthoritySnapshot(TypedDict):
    schema_version: int
    card_uid: str
    app_key: str
    connection_uid: str
    generation: int
    resource_uids: list[str]
    resource_revisions: dict[str, int]
    card_revision: int
    ownership_revision: int
    selection_revision: int
    binding_revision: str
    authority_version: str


class ExecutionAuthority(ExecutionAuthoritySnapshot):
    state: Literal["eligible"]
    started: Literal[False]


class ExecutionReceipt(TypedDict):
    schema_version: int
    request_uid: str
    card_uid: str
    generation: int
    state: Literal["requested"]
    started: Literal[False]
    authority: ExecutionAuthoritySnapshot


class ExecutionAcknowledgment(TypedDict):
    schema_version: int
    acknowledgment_uid: str
    request_uid: str
    event_uid: str
    runtime_reference: str
    state: Literal["received"]
    started: Literal[False]
    changed: bool


class ExecutionRequest(TypedDict):
    schema_version: int
    request_uid: str
    card_uid: str
    generation: int
    state: Literal["requested"]
    started: Literal[False]
    changed: bool
    authority: ExecutionAuthoritySnapshot


class RuntimePermit(TypedDict):
    schema_version: int
    request_uid: str
    acknowledgment_uid: str
    runtime_reference: str
    generation: int
    lease_uid: str
    state: Literal["authorized", "stop_requested", "stopped"]
    permit_execution: bool
    started: Literal[False]
    expires_at: str
    changed: NotRequired[bool]


class ExecutionStartReport(TypedDict):
    schema_version: int
    request_uid: str
    acknowledgment_uid: str
    runtime_reference: str
    generation: int
    lease_uid: str
    start_uid: str
    state: Literal["start_reported"]
    evidence_kind: Literal["app_attestation"]
    execution_reference: str
    reported_at: str
    changed: bool


class RuntimeStartEvidence(TypedDict):
    start_uid: str
    execution_reference: str
    reported_at: str


class RuntimeReport(RuntimePermit):
    evidence_kind: Literal["none", "app_attestation"]
    start_report: RuntimeStartEvidence | None
    active_report: bool


def _request_scope(board_uid: str, card_uid: str, request_uid: str) -> str:
    return f"/apps/v1/boards/{_uid(board_uid)}/cards/{_uid(card_uid)}/execution-requests/{_uid(request_uid)}"


def _scope(board_uid: str, card_uid: str, generation: int) -> str:
    if type(generation) is not int or generation < 1:
        raise ValueError("Execution generation must be positive")
    return f"/apps/v1/boards/{_uid(board_uid)}/cards/{_uid(card_uid)}"


class AppExecution:
    """Caller-owned app Bearer transport. No dispatch, implicit retries or token refresh."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def authority(self, board_uid: str, card_uid: str, *, generation: int) -> ExecutionAuthority:
        path = _scope(board_uid, card_uid, generation)
        return cast(ExecutionAuthority, await self.transport.request(
            "GET", f"{path}/execution-authority", params={"generation": generation},
        ))

    async def request(self, board_uid: str, card_uid: str, *, generation: int,
                      expected_authority_version: str) -> ExecutionRequest:
        path = _scope(board_uid, card_uid, generation)
        if (not isinstance(expected_authority_version, str) or len(expected_authority_version) != 64
                or any(c not in "0123456789abcdef" for c in expected_authority_version)):
            raise ValueError("Execution authority version must be a SHA256 hex digest")
        return cast(ExecutionRequest, await self.transport.request(
            "POST", f"{path}/execution-requests", json={"generation": generation,
                "expected_authority_version": expected_authority_version},
        ))

    async def read_request(self, board_uid: str, card_uid: str, *, request_uid: str) -> ExecutionReceipt:
        return cast(ExecutionReceipt, await self.transport.request(
            "GET", _request_scope(board_uid, card_uid, request_uid),
        ))

    async def acknowledge(self, board_uid: str, card_uid: str, *, request_uid: str,
                         event_uid: str, runtime_reference: str) -> ExecutionAcknowledgment:
        if not isinstance(runtime_reference, str) or not runtime_reference.strip() or len(runtime_reference) > 200:
            raise ValueError("Runtime reference must contain 1 to 200 characters")
        return cast(ExecutionAcknowledgment, await self.transport.request(
            "POST", f"{_request_scope(board_uid, card_uid, request_uid)}/acknowledgments",
            json={"event_uid": _uid(event_uid), "runtime_reference": runtime_reference},
        ))

    async def authorize_runtime(self, board_uid: str, card_uid: str, *, request_uid: str,
                                acknowledgment_uid: str, runtime_token: str) -> RuntimePermit:
        _runtime_token(runtime_token)
        return cast(RuntimePermit, await self.transport.request(
            "POST", f"{_request_scope(board_uid, card_uid, request_uid)}/runtime-permits",
            json={"acknowledgment_uid": _uid(acknowledgment_uid), "runtime_token": runtime_token},
        ))

    async def check_runtime(self, lease_uid: str, runtime_token: str, *, stopped: bool = False) -> RuntimePermit:
        _runtime_token(runtime_token)
        if type(stopped) is not bool:
            raise ValueError("Stopped must be boolean")
        return cast(RuntimePermit, await self.transport.request(
            "POST", f"/apps/v1/runtime-permits/{_uid(lease_uid)}/check",
            json={"runtime_token": runtime_token, "stopped": stopped},
        ))

    async def recover_runtime(self, request_uid: str, runtime_token: str) -> RuntimePermit:
        """Recover a lost response using the privately persisted token; no new lease."""
        _runtime_token(runtime_token)
        return cast(RuntimePermit, await self.transport.request(
            "POST", f"/apps/v1/execution-requests/{_uid(request_uid)}/runtime-permit-recovery",
            json={"runtime_token": runtime_token},
        ))

    async def report_start(self, board_uid: str, card_uid: str, *, request_uid: str,
                           lease_uid: str, runtime_token: str, execution_reference: str) -> ExecutionStartReport:
        """Report a caller-observed start. This does not start a process or move a card."""
        _runtime_token(runtime_token)
        if not isinstance(execution_reference, str) or not execution_reference.strip() or len(execution_reference) > 200:
            raise ValueError("Execution reference must contain 1 to 200 characters")
        return cast(ExecutionStartReport, await self.transport.request(
            "POST", f"{_request_scope(board_uid, card_uid, request_uid)}/start-reports",
            json={"lease_uid": _uid(lease_uid), "runtime_token": runtime_token,
                  "execution_reference": execution_reference},
        ))

    async def runtime_report(self, lease_uid: str, runtime_token: str) -> RuntimeReport:
        """Read current authority and start evidence without renewing the permit."""
        _runtime_token(runtime_token)
        return cast(RuntimeReport, await self.transport.request(
            "POST", f"/apps/v1/runtime-permits/{_uid(lease_uid)}/report",
            json={"runtime_token": runtime_token},
        ))


def _runtime_token(value):
    if not isinstance(value, str) or len(value) != 64 or any(c not in "0123456789abcdef" for c in value):
        raise ValueError("Runtime token must be 32 random bytes as lowercase hex")
