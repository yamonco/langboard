"""Read resources granted to the authenticated app connection, without execution authority."""

import re
from typing import TypedDict, cast
from .rest import ApiTransport


class AppResource(TypedDict):
    resource_uid: str
    resource_type: str
    external_resource_id: str
    resource_path: list[dict[str, str]]
    access_revision: int
    health: str


class AppResourcePage(TypedDict):
    schema_version: int
    connection_uid: str
    binding_revision: str
    items: list[AppResource]
    next_cursor: str | None


class CardResourceSelection(TypedDict):
    app_key: str
    connection_uid: str
    revision: int | None
    resource_uids: list[str]


class CardResourceSelectionUpdate(TypedDict):
    revision: int | None
    changed: bool
    resource_uids: list[str]


def _uid(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9]{11}", value):
        raise ValueError("A native 11-character UID is required")
    return value


class AppResources:
    """Use a separate app Bearer transport. Each page rechecks current host authority."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def list(self, board_uid: str, *, limit: int = 25, after_uid: str | None = None) -> AppResourcePage:
        board_uid = _uid(board_uid)
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ValueError("Resource page limit must be 1 to 50")
        params: dict = {"limit": limit}
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return cast(AppResourcePage, await self.transport.request(
            "GET", f"/apps/v1/boards/{board_uid}/resources", params=params,
        ))


class CardResources:
    """Human administrator configuration. Use a user transport, never app credentials."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    @staticmethod
    def _path(board_uid: str, card_uid: str, connection_uid: str) -> str:
        return f"/board/{_uid(board_uid)}/card/{_uid(card_uid)}/apps/connections/{_uid(connection_uid)}/resources"

    async def read(self, board_uid: str, card_uid: str, connection_uid: str) -> CardResourceSelection:
        return cast(CardResourceSelection, await self.transport.request(
            "GET", self._path(board_uid, card_uid, connection_uid),
        ))

    async def select(self, board_uid: str, card_uid: str, connection_uid: str,
                     resource_uids: list[str], *, expected_revision: int | None) -> CardResourceSelectionUpdate:
        path = self._path(board_uid, card_uid, connection_uid)
        if not isinstance(resource_uids, list) or len(resource_uids) > 20:
            raise ValueError("Select at most 20 distinct resource UIDs")
        resources = [_uid(uid) for uid in resource_uids]
        if len(set(resources)) != len(resources):
            raise ValueError("Select at most 20 distinct resource UIDs")
        if expected_revision is not None and (type(expected_revision) is not int or expected_revision < 1):
            raise ValueError("A current positive revision or initial null is required")
        return cast(CardResourceSelectionUpdate, await self.transport.request(
            "PUT", path, json={"resource_uids": resources, "expected_revision": expected_revision},
        ))
