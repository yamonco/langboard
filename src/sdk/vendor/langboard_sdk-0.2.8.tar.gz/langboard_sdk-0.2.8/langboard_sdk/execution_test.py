from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from .execution import AppExecution


class ExecutionTests(IsolatedAsyncioTestCase):
    async def test_exact_native_contract_and_no_started_inference(self):
        authority = {"state": "eligible", "started": False}
        receipt = {"state": "requested", "started": False, "request_uid": "0123456789A"}
        transport = SimpleNamespace(request=AsyncMock(side_effect=[authority, receipt]))
        app = AppExecution(transport)
        self.assertIs(await app.authority("ABCDEFGHIJK", "0123456789A", generation=3), authority)
        self.assertIs(await app.request("ABCDEFGHIJK", "0123456789A", generation=3, expected_authority_version="a" * 64), receipt)
        self.assertEqual(transport.request.await_args_list[0].args, ("GET", "/apps/v1/boards/ABCDEFGHIJK/cards/0123456789A/execution-authority"))
        self.assertEqual(transport.request.await_args_list[0].kwargs, {"params": {"generation": 3}})
        self.assertEqual(transport.request.await_args_list[1].kwargs, {"json": {"generation": 3, "expected_authority_version": "a" * 64}})

    async def test_invalid_scope_and_generation_never_dispatch(self):
        transport = SimpleNamespace(request=AsyncMock())
        app = AppExecution(transport)
        for operation in (app.authority, app.request):
            for generation in (0, -1, True, "3", None):
                with self.assertRaises(ValueError):
                    await operation("ABCDEFGHIJK", "0123456789A", generation=generation, **({"expected_authority_version": "a" * 64} if operation == app.request else {}))
            for board, card in (("../other", "0123456789A"), ("ABCDEFGHIJK", "../other")):
                with self.assertRaises(ValueError):
                    await operation(board, card, generation=3, **({"expected_authority_version": "a" * 64} if operation == app.request else {}))
        transport.request.assert_not_awaited()

    async def test_transport_error_is_not_retried_or_converted_into_acceptance(self):
        transport = SimpleNamespace(request=AsyncMock(side_effect=TimeoutError("unknown")))
        with self.assertRaises(TimeoutError):
            await AppExecution(transport).request("ABCDEFGHIJK", "0123456789A", generation=3, expected_authority_version="a" * 64)
        self.assertEqual(transport.request.await_count, 1)

    async def test_invalid_authority_version_never_dispatches(self):
        transport = SimpleNamespace(request=AsyncMock())
        app = AppExecution(transport)
        for version in (None, True, "", "A" * 64, "a" * 63):
            with self.assertRaises(ValueError):
                await app.request("ABCDEFGHIJK", "0123456789A", generation=3, expected_authority_version=version)
        transport.request.assert_not_awaited()

    async def test_readback_and_received_ack_have_exact_paths(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"started": False}))
        app = AppExecution(transport)
        await app.read_request("ABCDEFGHIJK", "0123456789A", request_uid="0123456789B")
        await app.acknowledge("ABCDEFGHIJK", "0123456789A", request_uid="0123456789B", event_uid="0123456789C", runtime_reference="runtime-1")
        self.assertEqual(transport.request.await_args_list[0].args, ("GET", "/apps/v1/boards/ABCDEFGHIJK/cards/0123456789A/execution-requests/0123456789B"))
        self.assertEqual(transport.request.await_args_list[1].kwargs, {"json": {"event_uid": "0123456789C", "runtime_reference": "runtime-1"}})

    async def test_runtime_permit_and_stop_exact_paths(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"started": False}))
        app = AppExecution(transport)
        await app.authorize_runtime("ABCDEFGHIJK", "0123456789A", request_uid="0123456789B", acknowledgment_uid="0123456789C", runtime_token="a"*64)
        await app.check_runtime("0123456789D", "a"*64, stopped=True)
        self.assertEqual(transport.request.await_args_list[0].kwargs, {"json": {"acknowledgment_uid": "0123456789C", "runtime_token": "a"*64}})
        self.assertEqual(transport.request.await_args_list[1].args, ("POST", "/apps/v1/runtime-permits/0123456789D/check"))
        self.assertEqual(transport.request.await_args_list[1].kwargs, {"json": {"runtime_token": "a"*64, "stopped": True}})
