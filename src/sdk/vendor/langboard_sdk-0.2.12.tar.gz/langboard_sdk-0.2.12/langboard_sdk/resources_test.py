from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from .resources import AppResources, CardResources


class ResourceTests(IsolatedAsyncioTestCase):
    async def test_bounded_page_uses_native_cursor_without_autofetch(self):
        page = {"items": [], "next_cursor": "0123456789A"}
        transport = SimpleNamespace(request=AsyncMock(return_value=page))
        result = await AppResources(transport).list("ABCDEFGHIJK", limit=2, after_uid="0123456789A")
        self.assertIs(result, page)
        transport.request.assert_awaited_once_with(
            "GET", "/apps/v1/boards/ABCDEFGHIJK/resources", params={"limit": 2, "after": "0123456789A"},
        )

    async def test_bad_scope_cursor_or_limit_never_dispatches(self):
        transport = SimpleNamespace(request=AsyncMock())
        reader = AppResources(transport)
        for board in ("../other", "board?override=1", "short", None):
            with self.assertRaises(ValueError):
                await reader.list(board)
        for limit in (True, "25", 0, 51):
            with self.assertRaises(ValueError):
                await reader.list("ABCDEFGHIJK", limit=limit)
        for after in ("../other", "short", "", 1):
            with self.assertRaises(ValueError):
                await reader.list("ABCDEFGHIJK", after_uid=after)
        transport.request.assert_not_awaited()


class CardResourceTests(IsolatedAsyncioTestCase):
    async def test_configuration_uses_user_route_and_explicit_revision_without_retry(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"revision": 2}))
        resources = CardResources(transport)
        args = ("ABCDEFGHIJK", "0123456789A", "abcdefghijk")
        path = "/board/ABCDEFGHIJK/card/0123456789A/apps/connections/abcdefghijk/resources"
        await resources.read(*args)
        transport.request.assert_awaited_with("GET", path)
        await resources.select(*args, [], expected_revision=1)
        transport.request.assert_awaited_with("PUT", path, json={"resource_uids": [], "expected_revision": 1})
        transport.request.reset_mock()
        transport.request.side_effect = RuntimeError("Response lost")
        with self.assertRaises(RuntimeError):
            await resources.select(*args, ["ABCDEFGHIJK"], expected_revision=None)
        transport.request.assert_awaited_once()

    async def test_invalid_scope_selection_or_revision_never_dispatches(self):
        transport = SimpleNamespace(request=AsyncMock())
        resources = CardResources(transport)
        args = ("ABCDEFGHIJK", "0123456789A", "abcdefghijk")
        for index in range(3):
            invalid = list(args)
            invalid[index] = "../other"
            with self.assertRaises(ValueError):
                await resources.read(*invalid)
        for selected in (["ABCDEFGHIJK"] * 2, ["ABCDEFGHIJK"] * 21, ["invalid"], "all", [None]):
            with self.assertRaises(ValueError):
                await resources.select(*args, selected, expected_revision=None)
        for revision in (True, 0, -1, "1"):
            with self.assertRaises(ValueError):
                await resources.select(*args, [], expected_revision=revision)
        transport.request.assert_not_awaited()
