from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from .execution import AppExecution


class ExecutionTests(IsolatedAsyncioTestCase):
    async def test_exact_native_contract_and_no_started_inference(self):
        authority = {"state": "eligible", "started": False}
        receipt = {"state": "requested", "started": False, "request_uid": "0123456789A"}
        transport = SimpleNamespace(request=AsyncMock(side_effect=[authority, receipt]))
        app = AppExecution(transport)
        self.assertIs(await app.authority("ABCDEFGHIJK", "0123456789A", generation=3), authority)
        self.assertIs(await app.request("ABCDEFGHIJK", "0123456789A", generation=3), receipt)
        self.assertEqual(transport.request.await_args_list[0].args, ("GET", "/apps/v1/boards/ABCDEFGHIJK/cards/0123456789A/execution-authority"))
        self.assertEqual(transport.request.await_args_list[0].kwargs, {"params": {"generation": 3}})
        self.assertEqual(transport.request.await_args_list[1].kwargs, {"json": {"generation": 3}})

    async def test_invalid_scope_and_generation_never_dispatch(self):
        transport = SimpleNamespace(request=AsyncMock())
        app = AppExecution(transport)
        for operation in (app.authority, app.request):
            for generation in (0, -1, True, "3", None):
                with self.assertRaises(ValueError):
                    await operation("ABCDEFGHIJK", "0123456789A", generation=generation)
            for board, card in (("../other", "0123456789A"), ("ABCDEFGHIJK", "../other")):
                with self.assertRaises(ValueError):
                    await operation(board, card, generation=3)
        transport.request.assert_not_awaited()

    async def test_transport_error_is_not_retried_or_converted_into_acceptance(self):
        transport = SimpleNamespace(request=AsyncMock(side_effect=TimeoutError("unknown")))
        with self.assertRaises(TimeoutError):
            await AppExecution(transport).request("ABCDEFGHIJK", "0123456789A", generation=3)
        self.assertEqual(transport.request.await_count, 1)
