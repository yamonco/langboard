"""Read resources granted to the authenticated app connection, without execution authority."""

import re
from typing import TypedDict, cast
from .rest import ApiTransport


class AppResource(TypedDict):
    resource_uid: str
    resource_type: str
    external_resource_id: str
    resource_path: list[dict[str, str]]
    access_revision: int
    health: str


class AppResourcePage(TypedDict):
    schema_version: int
    connection_uid: str
    binding_revision: str
    items: list[AppResource]
    next_cursor: str | None


def _uid(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9]{11}", value):
        raise ValueError("A native 11-character UID is required")
    return value


class AppResources:
    """Use a separate app Bearer transport. Each page rechecks current host authority."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def list(self, board_uid: str, *, limit: int = 25, after_uid: str | None = None) -> AppResourcePage:
        board_uid = _uid(board_uid)
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ValueError("Resource page limit must be 1 to 50")
        params: dict = {"limit": limit}
        if after_uid is not None:
            params["after"] = _uid(after_uid)
        return cast(AppResourcePage, await self.transport.request(
            "GET", f"/apps/v1/boards/{board_uid}/resources", params=params,
        ))
