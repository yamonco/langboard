"""Portable app policy and consent contracts; the authenticated host enforces them."""

import hashlib
import json
from dataclasses import dataclass
from enum import Enum
from typing import TypedDict
from .definition import APP_CAPABILITIES, validate_app_definition
from .management import _revision, _segment
from .rest import ApiTransport


class PolicyMode(str, Enum):
    DISABLED = "disabled"
    APPROVED_ONLY = "approved_only"
    PERSONAL_ALLOWED = "personal_allowed"


def effective_policy(instance: PolicyMode | str, organization: PolicyMode | str | None = None) -> PolicyMode:
    """An organization may restrict, but never relax, the instance policy."""
    modes = list(PolicyMode)
    instance = PolicyMode(instance)
    return instance if organization is None else modes[min(modes.index(instance), modes.index(PolicyMode(organization)))]


@dataclass(frozen=True)
class GovernanceDecision:
    distribution_allowed: bool
    connection_allowed: bool
    automation_allowed: bool


def evaluate_governance(
    instance: PolicyMode | str, organization: PolicyMode | str | None = None, *,
    approved: bool, distribution: str, connection: str, automation: str | None = None,
) -> GovernanceDecision:
    """Evaluate eligibility only. Actual grants and caller permissions remain required.

    Organization distribution and connections require instance approval. Shared
    organization automation always requires an organization-owned connection.
    A personal connection cannot inherit authority from organization distribution.
    """
    if type(approved) is not bool:
        raise ValueError("Approval must be explicit")
    if distribution not in ("personal", "organization") or connection not in ("personal", "organization"):
        raise ValueError("Distribution and connection must be personal or organization")
    if automation not in (None, "personal", "organization"):
        raise ValueError("Automation must be personal or organization")
    mode = effective_policy(instance, organization)
    enabled = mode != PolicyMode.DISABLED
    personal = approved or mode == PolicyMode.PERSONAL_ALLOWED
    distribution_allowed = enabled and (approved if distribution == "organization" else personal)
    # Personal account ownership does not require personal app distribution mode.
    connection_allowed = distribution_allowed and (approved if connection == "organization" else True)
    automation_allowed = connection_allowed and automation is not None and (
        (automation == "organization" and distribution == "organization" and connection == "organization")
        or (automation == "personal" and connection == "personal")
    )
    return GovernanceDecision(distribution_allowed, connection_allowed, automation_allowed)


def declaration_trust_fingerprint(declaration: dict) -> str:
    """Fingerprint declared destinations and identities; never contact a target."""
    item = validate_app_definition(declaration)
    trust = item.get("trust", {})
    identity = {
        "publisher": item.get("publisher"),
        "panel_url": (item.get("panel") or {}).get("url"),
        "mcp_identity": item.get("mcp", {}).get("identity"),
        **{field: sorted(trust.get(field, [])) for field in (
            "authentication_origins", "mcp_origins", "data_origins"
        )},
    }
    return hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class ConsentUpdate(TypedDict):
    retained: frozenset[str]
    newly_requested: frozenset[str]
    trust_changed: bool


def update_consent(old: dict, new: dict, granted) -> ConsentUpdate:
    """Preserve reviewed capability intersections; never grant new authority.

    MCP tool descriptions are declarations only, not capability grants. Tool
    execution requires separate host approval of each declared authority scope.
    """
    old, new = validate_app_definition(old), validate_app_definition(new)
    if old["key"] != new["key"]:
        raise ValueError("Consent updates must refer to the same app")
    if not isinstance(granted, (list, tuple, set, frozenset)) or any(
        not isinstance(scope, str) or scope not in APP_CAPABILITIES for scope in granted
    ):
        raise ValueError("Granted capabilities must be explicit supported scopes")
    requested = frozenset(new["capabilities"])
    changed = declaration_trust_fingerprint(old) != declaration_trust_fingerprint(new)
    retained = frozenset() if changed else frozenset(granted) & requested & frozenset(old["capabilities"])
    return {"retained": retained, "newly_requested": requested - frozenset(old["capabilities"]), "trust_changed": changed}


class GovernanceManager:
    """Current admin API client. Compatible host and caller authorization required."""

    path = "/settings/apps/governance"

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def instance(self) -> dict:
        return await self.transport.request("GET", self.path)

    async def set_instance(self, mode: PolicyMode | str, expected_revision: str) -> dict:
        return await self.transport.request("PUT", self.path, json={
            "mode": PolicyMode(mode).value, "expected_revision": _revision(expected_revision),
        })

    async def organization(self, organization_uid: str) -> dict:
        return await self.transport.request("GET", f"{self.path}/organizations/{_segment(organization_uid)}")

    async def set_organization(self, organization_uid: str, mode: PolicyMode | str | None, expected_revision: str) -> dict:
        return await self.transport.request("PUT", f"{self.path}/organizations/{_segment(organization_uid)}", json={
            "mode": None if mode is None else PolicyMode(mode).value, "expected_revision": _revision(expected_revision),
        })
