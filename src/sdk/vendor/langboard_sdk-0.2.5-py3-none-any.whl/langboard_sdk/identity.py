"""Inbound connection identity, separate from owner management authority."""

from .management import _segment
from .rest import ApiTransport


class ConnectionCredentials:
    """Use a user-authenticated transport. Tokens are never fetched implicitly."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def issue(self, connection_uid: str, *, expires_in_seconds: int = 3600) -> dict:
        if type(expires_in_seconds) is not int or not 60 <= expires_in_seconds <= 86400:
            raise ValueError("Credential lifetime must be 60 to 86400 seconds")
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/credentials",
            json={"expires_in_seconds": expires_in_seconds},
        )

    async def revoke(self, connection_uid: str, credential_uid: str) -> dict:
        return await self.transport.request(
            "POST", f"/settings/apps/connections/{_segment(connection_uid)}/credentials/{_segment(credential_uid)}/revoke",
        )


class AppIdentity:
    """Use a separately configured app credential transport. Identity grants no capabilities."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def current(self) -> dict:
        return await self.transport.request("GET", "/apps/v1/identity")
