"""Inspect authority and persist request acceptance; neither starts execution."""

from typing import Literal, TypedDict, cast
from .resources import _uid
from .rest import ApiTransport


class ExecutionAuthoritySnapshot(TypedDict):
    schema_version: int
    card_uid: str
    app_key: str
    connection_uid: str
    generation: int
    resource_uids: list[str]
    resource_revisions: dict[str, int]
    card_revision: int
    ownership_revision: int
    selection_revision: int
    binding_revision: str
    authority_version: str


class ExecutionAuthority(ExecutionAuthoritySnapshot):
    state: Literal["eligible"]
    started: Literal[False]


class ExecutionRequest(TypedDict):
    schema_version: int
    request_uid: str
    card_uid: str
    generation: int
    state: Literal["requested"]
    started: Literal[False]
    changed: bool
    authority: ExecutionAuthoritySnapshot


def _scope(board_uid: str, card_uid: str, generation: int) -> str:
    if type(generation) is not int or generation < 1:
        raise ValueError("Execution generation must be positive")
    return f"/apps/v1/boards/{_uid(board_uid)}/cards/{_uid(card_uid)}"


class AppExecution:
    """Caller-owned app Bearer transport. No dispatch, implicit retries or token refresh."""

    def __init__(self, transport: ApiTransport):
        self.transport = transport

    async def authority(self, board_uid: str, card_uid: str, *, generation: int) -> ExecutionAuthority:
        path = _scope(board_uid, card_uid, generation)
        return cast(ExecutionAuthority, await self.transport.request(
            "GET", f"{path}/execution-authority", params={"generation": generation},
        ))

    async def request(self, board_uid: str, card_uid: str, *, generation: int,
                      expected_authority_version: str) -> ExecutionRequest:
        path = _scope(board_uid, card_uid, generation)
        if (not isinstance(expected_authority_version, str) or len(expected_authority_version) != 64
                or any(c not in "0123456789abcdef" for c in expected_authority_version)):
            raise ValueError("Execution authority version must be a SHA256 hex digest")
        return cast(ExecutionRequest, await self.transport.request(
            "POST", f"{path}/execution-requests", json={"generation": generation,
                "expected_authority_version": expected_authority_version},
        ))
