"""Credential boundaries validate input before network dispatch."""

from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from .identity import ConnectionCredentials


class IdentityTests(IsolatedAsyncioTestCase):
    async def test_rejects_invalid_identifiers_and_lifetimes_without_dispatch(self):
        transport = SimpleNamespace(request=AsyncMock())
        credentials = ConnectionCredentials(transport)
        for value in (True, "3600", 59, 86401):
            with self.assertRaises(ValueError):
                await credentials.issue("connection", expires_in_seconds=value)
        for identifier in ("../other", "connection?override=true"):
            with self.assertRaises(ValueError):
                await credentials.issue(identifier)
            with self.assertRaises(ValueError):
                await credentials.revoke("connection", identifier)
        transport.request.assert_not_awaited()
