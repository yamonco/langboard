from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock
from .resources import AppResources


class ResourceTests(IsolatedAsyncioTestCase):
    async def test_bounded_page_uses_native_cursor_without_autofetch(self):
        page = {"items": [], "next_cursor": "0123456789A"}
        transport = SimpleNamespace(request=AsyncMock(return_value=page))
        result = await AppResources(transport).list("ABCDEFGHIJK", limit=2, after_uid="0123456789A")
        self.assertIs(result, page)
        transport.request.assert_awaited_once_with(
            "GET", "/apps/v1/boards/ABCDEFGHIJK/resources", params={"limit": 2, "after": "0123456789A"},
        )

    async def test_bad_scope_cursor_or_limit_never_dispatches(self):
        transport = SimpleNamespace(request=AsyncMock())
        reader = AppResources(transport)
        for board in ("../other", "board?override=1", "short", None):
            with self.assertRaises(ValueError):
                await reader.list(board)
        for limit in (True, "25", 0, 51):
            with self.assertRaises(ValueError):
                await reader.list("ABCDEFGHIJK", limit=limit)
        for after in ("../other", "short", "", 1):
            with self.assertRaises(ValueError):
                await reader.list("ABCDEFGHIJK", after_uid=after)
        transport.request.assert_not_awaited()
