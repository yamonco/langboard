"""Standalone governance security contracts, without host or runtime imports."""

from copy import deepcopy
from types import SimpleNamespace
from unittest import IsolatedAsyncioTestCase, TestCase, main
from unittest.mock import AsyncMock
from . import GovernanceManager, PolicyMode, effective_policy, evaluate_governance, update_consent
from .definition import validate_app_definition
from .governance import declaration_trust_fingerprint


DECLARATION = {
    "schema_version": 1, "key": "example-erp", "version": "1.0.0", "name": "Example ERP",
    "description": "External issues.", "capabilities": ["cards.create", "resources.read"],
    "resource_types": ["issue"], "publisher": "Example Org",
    "panel": {"url": "https://example.org/panel?v=1", "name": "ERP", "icon": "📋"},
    "trust": {"authentication_origins": ["https://auth.example.org"],
              "mcp_origins": ["https://mcp.example.org"], "data_origins": ["https://data.example.org"]},
    "mcp": {"identity": "example-erp-mcp", "tools": [
        {"name": "read_issue", "description": "Read an issue.", "authority_scope": "read"},
    ]},
}


class GovernanceTests(TestCase):
    def test_every_policy_pair_uses_most_restrictive_mode(self):
        modes = list(PolicyMode)
        for instance_index, instance in enumerate(modes):
            self.assertEqual(effective_policy(instance), instance)
            for org_index, organization in enumerate(modes):
                self.assertEqual(effective_policy(instance.value, organization.value), modes[min(instance_index, org_index)])
        for invalid in ("approved", "", True, None):
            with self.assertRaises(ValueError):
                effective_policy(invalid)

    def test_distribution_and_connection_require_current_policy(self):
        for mode in PolicyMode:
            for approved in (False, True):
                for distribution in ("personal", "organization"):
                    for connection in ("personal", "organization"):
                        decision = evaluate_governance(mode, approved=approved, distribution=distribution,
                                                       connection=connection, automation="organization")
                        enabled = mode != PolicyMode.DISABLED
                        available = approved or mode == PolicyMode.PERSONAL_ALLOWED
                        distribution_allowed = enabled and (approved if distribution == "organization" else available)
                        self.assertEqual(decision.distribution_allowed, distribution_allowed)
                        self.assertEqual(decision.connection_allowed,
                                         distribution_allowed and (approved if connection == "organization" else True))
                        if connection == "personal":
                            self.assertFalse(decision.automation_allowed)
        approved_org = evaluate_governance("personal_allowed", approved=True, distribution="organization",
                                           connection="organization", automation="organization")
        self.assertTrue(approved_org.automation_allowed)
        restricted = evaluate_governance("personal_allowed", "disabled", approved=True,
                                         distribution="organization", connection="organization", automation="organization")
        self.assertFalse(restricted.connection_allowed)
        self.assertFalse(restricted.automation_allowed)

    def test_approved_organization_app_accepts_personal_account_under_approved_only(self):
        decision = evaluate_governance("approved_only", approved=True,
                                       distribution="organization", connection="personal", automation="organization")
        self.assertTrue(decision.distribution_allowed)
        self.assertTrue(decision.connection_allowed)
        self.assertFalse(decision.automation_allowed)
        personal_execution = evaluate_governance("approved_only", approved=True,
                                                distribution="organization", connection="personal", automation="personal")
        self.assertTrue(personal_execution.automation_allowed)

    def test_invalid_governance_inputs_fail_closed(self):
        for change in ({"approved": 1}, {"distribution": "public"}, {"connection": "inherited"},
                       {"automation": "shared"}):
            with self.assertRaises(ValueError):
                evaluate_governance("personal_allowed", **{
                    "approved": True, "distribution": "personal", "connection": "personal", **change,
                })

    def test_backward_compatible_declarations_and_detached_copy(self):
        legacy = {key: value for key, value in DECLARATION.items() if key not in ("publisher", "trust", "mcp")}
        self.assertEqual(validate_app_definition(legacy), legacy)
        declaration_trust_fingerprint({**legacy, "panel": None})
        validated = validate_app_definition(DECLARATION)
        validated["trust"]["data_origins"].clear()
        self.assertTrue(DECLARATION["trust"]["data_origins"])

    def test_all_trust_identity_changes_clear_grants(self):
        changes = []
        for field in ("authentication_origins", "mcp_origins", "data_origins"):
            new = deepcopy(DECLARATION)
            new["trust"][field] = ["https://new.example.org"]
            changes.append(new)
        for field, value in (("publisher", "Other Org"), ("panel", {**DECLARATION["panel"], "url": "https://example.org/panel?v=2"}),
                             ("mcp", {**DECLARATION["mcp"], "identity": "other-mcp"})):
            changes.append({**DECLARATION, field: value})
        for new in changes:
            result = update_consent(DECLARATION, new, DECLARATION["capabilities"])
            self.assertTrue(result["trust_changed"])
            self.assertEqual(result["retained"], frozenset())

    def test_ordinary_update_retains_only_reviewed_intersection(self):
        new = {**DECLARATION, "version": "1.1.0", "description": "Changed description.",
               "capabilities": ["resources.read", "panels.render"]}
        result = update_consent(DECLARATION, new, ["cards.create", "resources.read", "panels.render"])
        self.assertFalse(result["trust_changed"])
        self.assertEqual(result["retained"], {"resources.read"})
        self.assertEqual(result["newly_requested"], {"panels.render"})
        self.assertNotIn("panels.render", result["retained"])
        self.assertNotIn("cards.create", result["retained"])

    def test_origin_order_is_not_a_trust_change_and_tools_never_grant(self):
        old = deepcopy(DECLARATION)
        old["trust"]["data_origins"].append("https://other.example.org")
        new = deepcopy(old)
        new["trust"]["data_origins"].reverse()
        new["mcp"]["tools"].append({"name": "automate", "description": "Run automation.", "authority_scope": "automation"})
        self.assertEqual(declaration_trust_fingerprint(old), declaration_trust_fingerprint(new))
        result = update_consent(old, new, [])
        self.assertEqual(result["retained"], frozenset())
        self.assertEqual(result["newly_requested"], frozenset())

    def test_invalid_origins_are_rejected(self):
        for origin in ("http://localhost:8000", "http://example.org", "https://EXAMPLE.org", "https://example.org:443",
                       "https://example.org/", "https://example.org/path", "https://example.org?x=1", "https://example.org#x",
                       "https://a:b@example.org", "https://example.org:bad", "https://example.org:70000",
                       "https://example.org:", "https://example.org ", "https://bad_host", "https://.example.org",
                       "https://example.org?", "https://example.org#", "https://example.org\\evil", None, 7):
            with self.subTest(origin=origin), self.assertRaises(ValueError):
                validate_app_definition({**DECLARATION, "trust": {**DECLARATION["trust"], "data_origins": [origin]}})
        for origin in ("https://localhost:8000", "https://example.org:8443", "https://[::1]"):
            validate_app_definition({**DECLARATION, "trust": {**DECLARATION["trust"], "data_origins": [origin]}})

    def test_invalid_extensions_are_rejected(self):
        for change in ({"publisher": " "}, {"publisher": None}, {"trust": {}}, {"mcp": None},
                       {"mcp": {"identity": "id", "tools": "*"}},
                       {"mcp": {"identity": "id", "tools": [{"name": "read", "description": "Read", "authority_scope": "admin"}]}},
                       {"mcp": {"identity": "id", "tools": [{"name": "*", "description": "Read", "authority_scope": "read"}]}},
                       {"mcp": {**DECLARATION["mcp"], "tools": DECLARATION["mcp"]["tools"] * 2}},
                       {"trust": {**DECLARATION["trust"], "data_origins": ["https://example.org"] * 2}},
                       {"mcp": {**DECLARATION["mcp"], "granted": True}}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                validate_app_definition({**DECLARATION, **change})
        with self.assertRaises(ValueError):
            update_consent(DECLARATION, {**DECLARATION, "key": "other-app"}, [])
        with self.assertRaises(ValueError):
            update_consent(DECLARATION, DECLARATION, "cards.create")


class GovernanceManagerTests(IsolatedAsyncioTestCase):
    async def test_routes_and_revision_payloads_use_caller_transport(self):
        transport = SimpleNamespace(request=AsyncMock(return_value={"mode": "approved_only", "revision": "a" * 64}))
        manager = GovernanceManager(transport)
        result = await manager.instance()
        await manager.set_instance(PolicyMode.APPROVED_ONLY, result["revision"])
        await manager.organization("org-1")
        await manager.set_organization("org-1", "disabled", result["revision"])
        await manager.set_organization("org-1", None, result["revision"])
        calls = transport.request.await_args_list
        self.assertEqual(calls[0].args, ("GET", "/settings/apps/governance"))
        self.assertEqual(calls[1].kwargs["json"], {"mode": "approved_only", "expected_revision": "a" * 64})
        self.assertEqual(calls[2].args, ("GET", "/settings/apps/governance/organizations/org-1"))
        self.assertEqual(calls[3].args, ("PUT", "/settings/apps/governance/organizations/org-1"))
        self.assertIsNone(calls[4].kwargs["json"]["mode"])

    async def test_invalid_revision_mode_and_identifier_never_send(self):
        transport = SimpleNamespace(request=AsyncMock())
        manager = GovernanceManager(transport)
        for revision in (None, True, 1, "", "a" * 63, "A" * 64):
            with self.assertRaises(ValueError):
                await manager.set_instance("disabled", revision)
            with self.assertRaises(ValueError):
                await manager.set_organization("org-1", "disabled", revision)
        with self.assertRaises(ValueError):
            await manager.set_instance("anything", "a" * 64)
        with self.assertRaises(ValueError):
            await manager.organization("../org")
        transport.request.assert_not_awaited()


if __name__ == "__main__":
    main()


class ExecutionConsentTest(TestCase):
    def test_execution_scope_requires_new_explicit_consent(self):
        new = {**DECLARATION, "version": "1.1.0", "capabilities": [*DECLARATION["capabilities"], "execution.run"]}
        result = update_consent(DECLARATION, new, DECLARATION["capabilities"])
        self.assertNotIn("execution.run", result["retained"])
        self.assertEqual(result["newly_requested"], {"execution.run"})
